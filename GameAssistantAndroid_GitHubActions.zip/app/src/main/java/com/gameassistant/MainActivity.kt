package com.gameassistant

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 40, 32, 24)
        }
        root.addView(TextView(this).apply {
            text = "GAME ASSISTANT"
            textSize = 26f
        })
        root.addView(TextView(this).apply {
            text = "Painel auxiliar para Android. Compatível como sobreposição visual; não controla o personagem nem automatiza o combate."
            textSize = 16f
            setPadding(0, 16, 0, 24)
        })
        root.addView(Button(this).apply {
            text = "1. Permitir aparecer sobre outros apps"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName"))
                    startActivity(intent)
                } else Toast.makeText(this@MainActivity, "Permissão já concedida", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply {
            text = "2. Abrir painel flutuante"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Conceda primeiro a permissão de sobreposição", Toast.LENGTH_LONG).show()
                } else {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                    Toast.makeText(this@MainActivity, "Painel iniciado", Toast.LENGTH_SHORT).show()
                }
            }
        })
        root.addView(Button(this).apply {
            text = "Fechar painel"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        })
        setContentView(root)
    }
}
