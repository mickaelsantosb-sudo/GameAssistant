# Game Assistant — Android

Protótipo nativo Android em Kotlin com painel flutuante auxiliar.

## O que inclui
- Tela inicial em português.
- Solicitação da permissão Android para aparecer sobre outros aplicativos.
- Painel flutuante arrastável.
- Perfil visual inicial para Albion Online.
- Botões demonstrativos de cronômetro e lembrete de pausa.

## Limites desta versão
Este app é um painel auxiliar. Não detecta mobs, não movimenta o personagem, não toca em controles do jogo, não injeta código e não contorna anti-cheat. Portanto, não faz farm automático no Albion Online.

## Como compilar
1. Abra a pasta `GameAssistantAndroid` no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Conecte um celular Android ou crie um emulador.
4. Execute o projeto pelo botão Run.

Requisitos: Android Studio recente, JDK 17 e Android SDK 35.

## Como usar
1. Instale e abra o app.
2. Toque em **Permitir aparecer sobre outros apps** e habilite a permissão nas configurações do Android.
3. Volte ao app e toque em **Abrir painel flutuante**.
4. Abra o Albion Online; o painel pode ficar sobre outros apps enquanto a permissão estiver ativa.

Em alguns aparelhos, a economia de bateria pode encerrar serviços em segundo plano.
